from __future__ import unicode_literals
from django.db import models
import re

EMAIL_REGEX =re.compile (r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def makeUser(self,firstname, lastname, email, password, confirmpassword):

        errors =[]

        if len(firstname) < 2:
            errors.append("first name is too short")

        if len(lastname) < 2:
            errors.append("last name is too short")

        if len(email) < 2:
            errors.append("email not valid")

        if len(password) < 8:
            errors.append("password is too short")

        if len(password) != len(confirmpassword):
            errors.append("emails do not match")

        if not errors:
            user = User.objects.create(firstname=firstname, lastname=lastname, email=email, password=password)
            return {"status":True, "data": user}

        else:
            return{"status": False, "data": errors}

    def log(self, email, password):
        error = []
        if len(User.objects.filter(email=email)) < 1 :
            error.append("email not valid")

        if User.objects.filter(email=email)[0].password != password:
            error.append("invalid password")
        return error

class User(models.Model):
    firstname = models.CharField(max_length = 26)
    lastname = models.CharField(max_length = 26)
    email = models.CharField(max_length = 26)
    password = models.CharField(max_length = 26)
    confirmpassword = models.CharField(max_length = 26)
    date_added = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()
