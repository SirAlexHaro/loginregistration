from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User

def index(request):
    return render(request,"login_app/index.html")

def success(request):
    context ={
    "users" : User.objects.filter()
    }
    return render(request, "login_app/success.html",context)

def add(request):

    if request.method == 'POST':
        answer = User.objects.makeUser(request.POST['firstname'],request.POST['lastname'],request.POST['email'],request.POST['password'],request.POST['confirmpassword'])
        if answer['status']:
            user = answer['data']
            messages.add_message(request, messages.SUCCESS,'successfully registered')

            request.session['firstname'] = request.POST['firstname']

            return redirect ('/success')
        else:
            for errors in answer['data']:
                messages.add_message(request, messages.ERROR, "registration {}".format(errors))
            return redirect('/')

def login(request):
    errors = User.objects.log(request.POST['email'],request.POST['password'])

    if len(errors) == 0:
        request.session['firstname'] = User.objects.filter(email=request.POST['email'])[0].firstname
        return redirect ('/success')

    else:
        messages.info (request,errors)
        return redirect ('/')
